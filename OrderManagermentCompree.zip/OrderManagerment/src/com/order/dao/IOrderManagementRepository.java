package com.order.dao;

import java.util.List;

import com.order.entity.Product;
import com.order.entity.User;
import com.order.exception.OrderNotFoundException;
import com.order.exception.UserAlreadyExistException;
import com.order.exception.UserNotFoundException;

public interface IOrderManagementRepository {
	void createOrder(User user, List<Product> products) throws UserAlreadyExistException;
    void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException;
    void createProduct(User adminUser, Product product) throws UserNotFoundException;
    void createUser(User user) throws UserAlreadyExistException;
    List<Product> getAllProducts();
    List<Product> getOrderByUser(User user) throws UserNotFoundException;

}

package com.order.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.order.entity.Product;
import com.order.entity.User;
import com.order.exception.OrderNotFoundException;
import com.order.exception.UserAlreadyExistException;
import com.order.exception.UserNotFoundException;

public class OrderProcessor implements IOrderManagementRepository {

	
	private Connection connection;
	public OrderProcessor(Connection connection) {
		this.connection = connection;
	}
	@Override
	public void createOrder(User user, List<Product> products) throws UserAlreadyExistException {
		 boolean userExists = checkUserExists(user);

	        if (!userExists) {
	            createUser(user);
	        }

	        // Now the user exists (either previously or just created), proceed to create the order
	        for (Product product : products) {
	            createOrderForUser(user.getUserId(), product.getProductId());
	        }

	        System.out.println("Order created successfully.");
	}
	    
	
	private void createOrderForUser(int userId, int productId) {
        String insertOrderQuery = "INSERT INTO Orders(userId, productId) VALUES (?, ?)";
        try {
            PreparedStatement insertOrderStatement = connection.prepareStatement(insertOrderQuery);
            insertOrderStatement.setInt(1, userId);
            insertOrderStatement.setInt(2, productId);
            insertOrderStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQLException appropriately
        }
    }

	@Override
	public void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException {
		// TODO Auto-generated method stub
		  String checkUserQuery = "SELECT userId FROM User WHERE userId = ?";
	        String checkOrderQuery = "SELECT orderId FROM Order WHERE userId = ? AND orderId = ?";
	        String cancelOrderQuery = "DELETE FROM Order WHERE userId = ? AND orderId = ?";

	        try {
	            // Check if the user exists
	            PreparedStatement checkUserStatement = connection.prepareStatement(checkUserQuery);
	            checkUserStatement.setInt(1, userId);
	            ResultSet userResultSet = checkUserStatement.executeQuery();

	            if (!userResultSet.next()) {
	                throw new UserNotFoundException("User with ID " + userId + " not found.");
	            }

	            // Check if the order exists for the given user
	            PreparedStatement checkOrderStatement = connection.prepareStatement(checkOrderQuery);
	            checkOrderStatement.setInt(1, userId);
	            checkOrderStatement.setInt(2, orderId);
	            ResultSet orderResultSet = checkOrderStatement.executeQuery();

	            if (!orderResultSet.next()) {
	                throw new OrderNotFoundException("Order with ID " + orderId + " not found for user ID " + userId);
	            }

	            // Cancel the order
	            PreparedStatement cancelOrderStatement = connection.prepareStatement(cancelOrderQuery);
	            cancelOrderStatement.setInt(1, userId);
	            cancelOrderStatement.setInt(2, orderId);
	            cancelOrderStatement.executeUpdate();

	            System.out.println("Order canceled successfully.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	            // Handle SQLException appropriately
	        }
	    }
		
	

	@Override
	public void createProduct(User adminUser, Product product) throws UserNotFoundException {
		// TODO Auto-generated method stub
		 if (!adminUser.getRole().equals("Admin")) {
	            throw new UserNotFoundException("User does not have the required privileges to create a product.");
	        }

	        String insertProductQuery = "INSERT INTO Product(productId, productName, description, price, quantityInStock, type) VALUES (?, ?, ?, ?, ?, ?)";

	        try {
	            PreparedStatement insertProductStatement = connection.prepareStatement(insertProductQuery);
	            insertProductStatement.setInt(1, product.getProductId());
	            insertProductStatement.setString(2, product.getProductName());
	            insertProductStatement.setString(3, product.getDescription());
	            insertProductStatement.setDouble(4, product.getPrice());
	            insertProductStatement.setInt(5, product.getQuantityInStock());
	            insertProductStatement.setString(6, product.getType());

	            insertProductStatement.executeUpdate();
	            System.out.println("Product created and stored in the database.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	            // Handle SQLException appropriately
	        }
	}

	@Override
	public void createUser(User user) throws UserAlreadyExistException {
		// TODO Auto-generated method stub
		 
		 String checkUserQuery = "SELECT userId FROM User WHERE userId = ?";
	        String insertUserQuery = "INSERT INTO User(userId, username, password, role) VALUES (?, ?, ?, ?)";

	      
	             try {
	                 // Check if user already exists
	                 PreparedStatement checkStatement = connection.prepareStatement(checkUserQuery);
	                 checkStatement.setInt(1, user.getUserId());
	                 ResultSet resultSet = checkStatement.executeQuery();
	                 if (resultSet.next()) {
	                     throw new UserAlreadyExistException("User with the same ID already exists.");
	                 }

	                 // Insert new user
	                 PreparedStatement insertStatement = connection.prepareStatement(insertUserQuery);
	                 insertStatement.setInt(1, user.getUserId());
	                 insertStatement.setString(2, user.getUsername());
	                 insertStatement.setString(3, user.getPassword());
	                 insertStatement.setString(4, user.getRole());
	                 insertStatement.executeUpdate();

	                 System.out.println("User created and stored in the database.");
	             } catch (SQLException e) {
	                 e.printStackTrace();
	                 // Handle SQLException appropriately
	             }
		
	}

	@Override
	public List<Product> getAllProducts() {
		   List<Product> productList = new ArrayList<>();
	        String query = "SELECT * FROM Product";

	        try {
	            PreparedStatement statement = connection.prepareStatement(query);
	            ResultSet resultSet = statement.executeQuery();

	            while (resultSet.next()) {
	                int productId = resultSet.getInt("productId");
	                String productName = resultSet.getString("productName");
	                String description = resultSet.getString("description");
	                double price = resultSet.getDouble("price");
	                int quantityInStock = resultSet.getInt("quantityInStock");
	                String type = resultSet.getString("type");

	                Product product = new Product(productId, productName, description, price, quantityInStock, type);
	                productList.add(product);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            // Handle SQLException appropriately
	        }
	        return productList;
	}
	

	@Override
	public List<Product> getOrderByUser(User user) throws UserNotFoundException {
		 List<Product> orderedProducts = new ArrayList<>();
	        String query = "SELECT p.* FROM Product p INNER JOIN Orders o ON p.productId = o.productId WHERE o.userId = ?";

	        try {
	            PreparedStatement statement = connection.prepareStatement(query);
	            statement.setInt(1, user.getUserId());
	            ResultSet resultSet = statement.executeQuery();

	            while (resultSet.next()) {
	                int productId = resultSet.getInt("productId");
	                String productName = resultSet.getString("productName");
	                String description = resultSet.getString("description");
	                double price = resultSet.getDouble("price");
	                int quantityInStock = resultSet.getInt("quantityInStock");
	                String type = resultSet.getString("type");

	                Product product = new Product(productId, productName, description, price, quantityInStock, type);
	                orderedProducts.add(product);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            // Handle SQLException appropriately
	        }
	        return orderedProducts;
	    }
	   private boolean checkUserExists(User user) {
	        String query = "SELECT userId FROM User WHERE userId = ?";
	        try {
	            PreparedStatement statement = connection.prepareStatement(query);
	            statement.setInt(1, user.getUserId());
	            return statement.executeQuery().next();
	        } catch (SQLException e) {
	            e.printStackTrace();
	            // Handle SQLException appropriately
	        }
	        return false;
	    }
	    // Other method
	}



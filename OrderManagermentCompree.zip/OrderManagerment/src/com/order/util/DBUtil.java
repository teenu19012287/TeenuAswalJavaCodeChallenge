package com.order.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DBUtil {
	private static Connection connStudent;
	 
	public static Connection createConnection() throws ClassNotFoundException,
			SQLException {
		ResourceBundle resMySQL = ResourceBundle.getBundle("mysql");
 
		String url = resMySQL.getString("url");
		String username = resMySQL.getString("username");
		String password = resMySQL.getString("password");
		String driver = resMySQL.getString("driver");
 
		Class.forName(driver);
 
		connStudent = DriverManager.getConnection(url, username, password);
		System.out.println("Connection established.");
		return connStudent;
	}
 
	public static void closeConnection() throws SQLException {
		connStudent.close();
	}
}
